import TKCoordinator
import TKUIKit
import UIKit

final class CollectiblesContainerViewController: GenericViewViewController<CollectiblesContainerView>, ScrollViewController {
    private let viewModel: CollectiblesContainerViewModel

    // MARK: - ScrollViewController

    func scrollToTop() {
        collectiblesViewController?.scrollToTop()
    }

    var collectiblesViewController: CollectiblesListViewController? {
        didSet {
            oldValue?.willMove(toParent: nil)
            customView.setContentView(nil)
            oldValue?.removeFromParent()

            setupCollectiblesViewController()
        }
    }

    init(viewModel: CollectiblesContainerViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        viewModel.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    private func setup() {
        setupCollectiblesViewController()
    }

    private func setupCollectiblesViewController() {
        guard isViewLoaded, let collectiblesViewController else { return }
        addChild(collectiblesViewController)
        customView.setContentView(collectiblesViewController.view)
        collectiblesViewController.didMove(toParent: self)
    }
}
