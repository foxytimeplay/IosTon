import Foundation
import KeeperCore
import URKit

struct SignerScannerControllerConfigurator: ScannerControllerConfigurator {
    enum Error: Swift.Error {
        case unsupportedDeeplink(deeplink: Deeplink)
    }

    private let deeplinkParser: DeeplinkParser
    private let urDecoder = URDecoder()

    init(deeplinkParser: DeeplinkParser) {
        self.deeplinkParser = deeplinkParser
    }

    func handleQRCode(_ qrCode: String) throws -> Deeplink {
        let deeplink = try deeplinkParser.parse(string: qrCode, source: .qr)

        guard case let .externalSign(externalSign) = deeplink,
              case .link = externalSign
        else {
            throw Error.unsupportedDeeplink(deeplink: deeplink)
        }
        return deeplink
    }

    func handleQRCodeUR(_ qrCode: String) throws -> UR {
        urDecoder.receivePart(qrCode)

        guard let result = urDecoder.result else {
            throw URError.noResult
        }
        return try result.get()
    }
}
