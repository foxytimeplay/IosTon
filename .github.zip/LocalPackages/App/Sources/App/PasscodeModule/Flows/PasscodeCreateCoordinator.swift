import KeeperCore
import TKCoordinator
import TKLocalize
import TKUIKit
import UIKit

final class PasscodeCreateCoordinator: RouterCoordinator<NavigationControllerRouter> {
    var didCreatePasscode: ((String) -> Void)?
    var didCancel: (() -> Void)?
    var didMismatch: (() -> Void)?

    private let biometryEnabler: PasscodeBiometryEnabler?
    private let passcodeNavigationController = UINavigationController()
    private var passcodeInputs = [PasscodeInputModuleInput]()

    init(
        router: NavigationControllerRouter,
        biometryEnabler: PasscodeBiometryEnabler? = nil
    ) {
        self.biometryEnabler = biometryEnabler
        super.init(router: router)
        passcodeNavigationController.setNavigationBarHidden(true, animated: false)
    }

    override func start() {
        open()
    }
}

private extension PasscodeCreateCoordinator {
    func open() {
        let passcodeModule = PasscodeAssembly.module(
            navigationController: passcodeNavigationController
        )

        passcodeModule.output.didTapBackspace = { [weak self] in
            self?.passcodeInputs.last?.didTapBackspace()
        }

        passcodeModule.output.didTapDigit = { [weak self] digit in
            self?.passcodeInputs.last?.didTapDigit(digit)
        }

        if router.rootViewController.viewControllers.isEmpty {
            passcodeModule.view.setupLeftCloseButton { [weak self] in
                self?.didCancel?()
            }
        } else {
            passcodeModule.view.setupBackButton()
        }

        router.push(
            viewController: passcodeModule.view,
            animated: true
        )
        openCreatePasscode()
    }

    func openCreatePasscode() {
        let passcodeInput = PasscodeInputAssembly.module(
            title: TKLocales.Passcode.create
        )

        passcodeInput.output.validateInput = { _ in
            .none
        }

        passcodeInput.output.didFinish = { [weak self] passcode in
            self?.openReenterPasscode(enteredPasscode: passcode)
        }

        passcodeInputs.append(passcodeInput.input)

        passcodeNavigationController.pushViewController(
            passcodeInput.viewController,
            animated: true
        )
    }

    func openReenterPasscode(enteredPasscode: String) {
        let passcodeInput = PasscodeInputAssembly.module(
            title: TKLocales.Passcode.reenter
        )

        passcodeInput.output.validateInput = { passcode in
            passcode == enteredPasscode ? .success : .failed
        }

        passcodeInput.output.didFinish = { [weak self] passcode in
            Task {
                if let enabler = self?.biometryEnabler {
                    await enabler.offerBiometry(passcode: passcode)
                }
                await MainActor.run {
                    self?.didCreatePasscode?(passcode)
                }
            }
        }

        passcodeInput.output.didFailed = { [weak self] in
            self?.didMismatch?()
            self?.passcodeNavigationController.popViewController(animated: true)
            _ = self?.passcodeInputs.popLast()
        }

        passcodeInputs.append(passcodeInput.input)

        passcodeNavigationController.pushViewController(
            passcodeInput.viewController,
            animated: true
        )
    }
}

extension PasscodeCreateCoordinator {
    static func present(
        parentCoordinator: Coordinator,
        parentRouter: NavigationControllerRouter,
        biometryEnabler: PasscodeBiometryEnabler? = nil,
        onCancel: @escaping () -> Void,
        onMismatch: @escaping () -> Void = {},
        onCreate: @escaping (String) -> Void
    ) {
        let coordinator = PasscodeCreateCoordinator(
            router: parentRouter,
            biometryEnabler: biometryEnabler
        )

        coordinator.didCancel = { [weak coordinator, weak parentCoordinator] in
            parentRouter.dismiss(animated: true) {
                parentCoordinator?.removeChild(coordinator)
                onCancel()
            }
        }

        coordinator.didCreatePasscode = { passcode in
            onCreate(passcode)
        }

        coordinator.didMismatch = onMismatch

        parentCoordinator.addChild(coordinator)
        coordinator.start()
    }
}
