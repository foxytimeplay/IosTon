import KeeperCore
import SnapKit
import TKUIKit
import UIKit

final class BrowserExploreFeaturedView: UIView {
    var didSelectApp: ((Dapp) -> Void)?
    var didSelectPopularApp: ((PopularApp) -> Void)?

    // MARK: - Image Loader

    var dapps = [PopularApp]() {
        didSet {
            guard dapps != oldValue else { return }
            let models = dapps.map { dapp in
                mapDapp(dapp)
            }

            let dataSource = (0 ..< Int.numberOfAdditionalItems).reduce(into: [BrowserExploreFeaturedCell.Model]()) { partialResult, _ in
                partialResult = partialResult + models
            }

            self.dataSource = dataSource
        }
    }

    private var dataSource = [BrowserExploreFeaturedCell.Model]() {
        didSet {
            collectionView.alpha = 0
            collectionView.reloadData()
            collectionView.layoutIfNeeded()

            slideshowTask?.cancel()
            slideshowTask = nil
            guard !dataSource.isEmpty else { return }

            DispatchQueue.main.async {
                let indexOfLeftSignificantCell = Int.numberOfAdditionalItems / 2 * self.dapps.count
                self.safeCollectionViewScroll(
                    at: IndexPath(item: indexOfLeftSignificantCell, section: 0),
                    at: .centeredHorizontally,
                    animated: false
                )

                UIView.animate(withDuration: 0.2) {
                    self.collectionView.alpha = 1.0
                }
                self.startSlideShowTask()
            }
        }
    }

    private lazy var collectionView = CollectionView(frame: .zero, collectionViewLayout: createLayout())

    private var indexOfCellBeforeDragging = 0
    private var slideshowTask: Task<Void, Never>?

    private enum Layout {
        static let cellSpacing: CGFloat = 8
        static let neighborPeek: CGFloat = 8
        static let itemHorizontalInset = cellSpacing / 2
    }

    func createLayout() -> UICollectionViewLayout {
        let configuration = UICollectionViewCompositionalLayoutConfiguration()
        configuration.scrollDirection = .horizontal

        return UICollectionViewCompositionalLayout(sectionProvider: { _, environment -> NSCollectionLayoutSection? in
            let width = environment.container.effectiveContentSize.width

            let itemSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1.0),
                heightDimension: .absolute(environment.container.effectiveContentSize.height)
            )
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            item.contentInsets = .init(
                top: 0,
                leading: Layout.itemHorizontalInset,
                bottom: 0,
                trailing: Layout.itemHorizontalInset
            )

            let groupSize = NSCollectionLayoutSize(
                widthDimension: .absolute(self.calculateItemSize(width: width)),
                heightDimension: .absolute(environment.container.effectiveContentSize.height)
            )

            let group = NSCollectionLayoutGroup.vertical(layoutSize: groupSize, subitems: [item])

            return NSCollectionLayoutSection(group: group)

        }, configuration: configuration)
    }

    func calculateItemSize(width: CGFloat) -> CGFloat {
        width - Layout.cellSpacing - Layout.neighborPeek * 2
    }

    override init(frame: CGRect) {
        super.init(frame: frame)

        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.decelerationRate = .fast
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(
            BrowserExploreFeaturedCell.self,
            forCellWithReuseIdentifier: BrowserExploreFeaturedCell.reuseIdentifier
        )

        addSubview(collectionView)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        collectionView.frame = bounds
    }

    func startSlideShow() {
        startSlideShowTask()
    }

    func stopSlideShow() {
        slideshowTask?.cancel()
        slideshowTask = nil
    }

    override func didMoveToSuperview() {
        guard superview != nil else {
            stopSlideShow()
            return
        }
        startSlideShow()
    }
}

private extension BrowserExploreFeaturedView {
    func indexOfMostVisibleCell(offset: Int = 0) -> Int {
        let itemWidth = calculateItemSize(width: collectionView.bounds.width)
        let proportionalOffset = collectionView.contentOffset.x / itemWidth
        let index = Int(round(proportionalOffset)) + offset
        let numberOfItems = collectionView.numberOfItems(inSection: 0)
        return max(0, min(numberOfItems - 1, index))
    }

    func startSlideShowTask() {
        slideshowTask?.cancel()
        slideshowTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            guard !Task.isCancelled else { return }
            resetCarouselIfNeeded()
            self.collectionView.isScrollEnabled = false
            UIView.animate(withDuration: 0.5) {
                self.safeCollectionViewScroll(
                    at: IndexPath(item: self.indexOfMostVisibleCell(offset: 1), section: 0),
                    at: .centeredHorizontally,
                    animated: true
                )
            } completion: { _ in
                self.collectionView.isScrollEnabled = true
                self.startSlideShowTask()
            }
        }
    }

    func safeCollectionViewScroll(
        at indexPath: IndexPath,
        at scrollPosition: UICollectionView.ScrollPosition,
        animated: Bool
    ) {
        guard collectionView.numberOfSections > indexPath.section,
              collectionView.numberOfItems(inSection: indexPath.section) > indexPath.item else { return }

        collectionView.scrollToItem(at: indexPath, at: scrollPosition, animated: animated)
    }
}

extension BrowserExploreFeaturedView: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        dataSource.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: BrowserExploreFeaturedCell.reuseIdentifier,
            for: indexPath
        )

        (cell as? BrowserExploreFeaturedCell)?.configure(model: dataSource[indexPath.item])

        return cell
    }
}

extension BrowserExploreFeaturedView: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        dataSource[indexPath.item].tapClosure?()
    }

    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        indexOfCellBeforeDragging = indexOfMostVisibleCell()
        slideshowTask?.cancel()
    }

    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        targetContentOffset.pointee = scrollView.contentOffset

        let indexOfMostVisibleCell = self.indexOfMostVisibleCell()
        let numberOfItems = collectionView.numberOfItems(inSection: 0)
        let swipeVelocityThreshold: CGFloat = 0.5
        let hasEnoughVelocityToSlideToTheNextCell = indexOfCellBeforeDragging + 1 < numberOfItems && velocity.x > swipeVelocityThreshold
        let hasEnoughVelocityToSlideToThePreviousCell = indexOfCellBeforeDragging - 1 >= 0 && velocity.x < -swipeVelocityThreshold
        let majorCellIsTheCellBeforeDragging = indexOfMostVisibleCell == indexOfCellBeforeDragging
        let didUseSwipeToSkipCell = majorCellIsTheCellBeforeDragging && (hasEnoughVelocityToSlideToTheNextCell || hasEnoughVelocityToSlideToThePreviousCell)

        if didUseSwipeToSkipCell {
            let snapToIndex = indexOfCellBeforeDragging + (hasEnoughVelocityToSlideToTheNextCell ? 1 : -1)
            let toValue = calculateItemSize(width: collectionView.bounds.width) * CGFloat(snapToIndex)
            let centeredOffset = centeredItemOffset(width: collectionView.bounds.width)

            UIView.animate(
                withDuration: 0.5,
                delay: 0,
                usingSpringWithDamping: 1,
                initialSpringVelocity: velocity.x,
                options: .allowUserInteraction,
                animations: {
                    scrollView.contentOffset = CGPoint(x: toValue - centeredOffset, y: 0)
                    scrollView.layoutIfNeeded()
                },
                completion: nil
            )

        } else {
            let indexPath = IndexPath(row: indexOfMostVisibleCell, section: 0)
            safeCollectionViewScroll(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }

    func centeredItemOffset(width: CGFloat) -> CGFloat {
        (width - calculateItemSize(width: width)) / 2
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        resetCarouselIfNeeded()
        startSlideShowTask()
    }

    func resetCarouselIfNeeded() {
        let indexOfMostVisibleCell = self.indexOfMostVisibleCell()
        let indexOfLeftSignificantCell = Int.numberOfAdditionalItems / 2 * self.dapps.count
        let indexOfRightSignificantCell = indexOfLeftSignificantCell + self.dapps.count - 1

        if indexOfMostVisibleCell == indexOfLeftSignificantCell - 1 {
            safeCollectionViewScroll(
                at: IndexPath(item: indexOfRightSignificantCell, section: 0),
                at: .centeredHorizontally,
                animated: false
            )
        }

        if indexOfMostVisibleCell == indexOfRightSignificantCell + 1 {
            safeCollectionViewScroll(
                at: IndexPath(item: indexOfLeftSignificantCell, section: 0),
                at: .centeredHorizontally,
                animated: false
            )
        }
    }

    func mapDapp(_ popularApp: PopularApp) -> BrowserExploreFeaturedCell.Model {
        let textColor: UIColor
        if let itemTextColor = popularApp.textColor {
            textColor = UIColor(hex: itemTextColor)
        } else {
            textColor = .Constant.white
        }

        let listConfiguration = TKListItemContentView.Configuration(
            iconViewConfiguration: TKListItemIconView.Configuration(
                content: .image(
                    TKImageView.Model(
                        image: .urlImage(popularApp.icon),
                        tintColor: .clear,
                        size: .size(CGSize(width: 44, height: 44)),
                        corners: .cornerRadius(cornerRadius: 12)
                    )
                ),
                alignment: .top,
                cornerRadius: 12,
                backgroundColor: .clear,
                size: CGSize(width: 44, height: 44)
            ),
            textContentViewConfiguration: TKListItemTextContentView.Configuration(
                titleViewConfiguration: TKListItemTitleView.Configuration(
                    title: popularApp.name
                ),
                captionViewsConfigurations: [TKListItemTextView.Configuration(
                    text: popularApp.description,
                    color: textColor.withAlphaComponent(0.76),
                    textStyle: .body3Alternate,
                    numberOfLines: 2
                )]
            )
        )

        return BrowserExploreFeaturedCell.Model(
            posterImageModel: TKImageView.Model(
                image: .urlImage(popularApp.poster),
                tintColor: .clear,
                size: .none
            ),
            listConfiguration: listConfiguration,
            tapClosure: { [weak self] in
                if let didSelectPopularApp = self?.didSelectPopularApp {
                    didSelectPopularApp(popularApp)
                    return
                }

                guard let dapp = Dapp(popularApp: popularApp) else { return }
                self?.didSelectApp?(dapp)
            }
        )
    }
}

private extension Int {
    static let numberOfAdditionalItems = 5
}

private class CollectionView: UICollectionView {
    private var _safeAreaInsets: UIEdgeInsets?
    override var safeAreaInsets: UIEdgeInsets {
        get { _safeAreaInsets ?? super.safeAreaInsets }
        set { _safeAreaInsets = newValue }
    }
}
