import KeeperCore
import UIKit

protocol HistoryContainerModuleOutput: AnyObject {
    var didChangeWallet: ((Wallet) -> Void)? { get set }
}

protocol HistoryContainerViewModel: AnyObject {
    func viewDidLoad()
}

final class HistoryContainerViewModelImplementation: HistoryContainerViewModel, HistoryContainerModuleOutput {
    // MARK: - HistoryContainerModuleOutput

    var didChangeWallet: ((Wallet) -> Void)?

    // MARK: - HistoryContainerModuleInput

    // MARK: - HistoryContainerViewModel

    func viewDidLoad() {
        walletsStore.addObserver(self) { observer, event in
            DispatchQueue.main.async {
                switch event {
                case let .didChangeActiveWallet(_, previousWallet):
                    observer.didChangeWallet?(previousWallet)
                default: break
                }
            }
        }

        guard let wallet = try? walletsStore.activeWallet else { return }
        didChangeWallet?(wallet)
    }

    private let walletsStore: WalletsStore

    init(walletsStore: WalletsStore) {
        self.walletsStore = walletsStore
    }
}
